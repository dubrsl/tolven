﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace submitCCRClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Tolven : DocumentService... ");


            DocumentService lServer = new DocumentService();


            Console.WriteLine("Enter the File Name - ");
            string lFileName = Console.ReadLine();

            Console.WriteLine("Enter the Account Id - ");
            string lAccountId = Console.ReadLine();

            Console.WriteLine("Enter the User Id - ");
            string lUserId = Console.ReadLine();


            byte[] buff = null;

            try
            {
                FileStream fs = new FileStream(lFileName, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                long numBytes = new FileInfo(lFileName).Length;
                buff = br.ReadBytes((int)numBytes);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            
            

            queueMessage larg = new queueMessage();
            larg.byte_1 = buff;
            larg.long_1 = Convert.ToInt64(lAccountId);
            larg.long_2 = Convert.ToInt64(lUserId);
            larg.String_1 = "urn:astm-org:CCR";

            Console.WriteLine("Tolven : submitCCR...... " );

            queueMessageResponse lres = lServer.queueMessage(larg);
            Console.WriteLine("Result  : " + lres.result);
            

 

        }
    }
}
