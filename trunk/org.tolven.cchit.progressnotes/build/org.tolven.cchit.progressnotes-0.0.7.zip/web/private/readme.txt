This folder contains the login.xhtml page and a few other special pages that usually don't display.

To avoid conflicts with other files that might be merged to this folder, consider using a sub-folder
using your plugin id for those files uniquely yours.
A file in this folder with the same name as a file in the Tolven core will override the default. 