This folder will contain .xhtml files used by Ajax callbacks from the browser. 

To avoid conflicts with other pages that might be merged to this folder, consider using a sub-folder
using your plugin id for those pages uniquely yours.
A file in this directory with the same name as a file in the Tolven core will override the default. 